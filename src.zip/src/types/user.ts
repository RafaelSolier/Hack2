export interface User {
  email: string
  token: string
}