
export interface ExpenseCategory {
  id: number
  name: string
}

export interface ExpenseCategoryCreate {
  id: number
}