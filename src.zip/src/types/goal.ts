export interface Goal {
  id: number
  month: number
  year: number
  amount: number
}